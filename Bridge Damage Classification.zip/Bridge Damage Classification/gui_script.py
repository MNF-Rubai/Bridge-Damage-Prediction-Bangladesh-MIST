"""
Bridge Damage Prediction System GUI
-----------------------------------

Author:
M Nafis Farhan Rubai
RIAD SHAHARIAR
MD. TAHMIDUL HAQ

Thesis Project: Bridge Damage Classification
Version: 1.0

Description
-----------
This application provides a graphical interface for predicting bridge damage
classes using a trained Gradient Boosting model. It integrates domain-driven
features such as salinity mapping and BNBC seismic zoning, and generates
formal PDF reports for decision support.

This version removes the duplicate Bridge Length field (keeps a single
Bridge Length input under Additional Parameters), keeps tightened vertical
spacing between sections, adds a scrollable left input area, and updates
the author display to a multi-line format. All model logic is preserved.
"""

# gui.py
import sys
import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import numpy as np
import pandas as pd
import joblib
import webbrowser
import threading
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas as pdf_canvas
from reportlab.platypus import Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet

# -------------------------
# Utility: resource path for PyInstaller
# -------------------------
def resource_path(relative_path: str) -> str:
    if getattr(sys, "frozen", False):
        base_path = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    else:
        base_path = os.path.dirname(__file__)
    return os.path.join(base_path, relative_path)

# -------------------------
# Paths and folders (relative to script/exe)
# -------------------------
MODEL_FILENAME = "Gradient_Boosting_Final.pkl"
MODEL_PATH = resource_path(MODEL_FILENAME)

if getattr(sys, "frozen", False):
    APP_BASE = os.path.dirname(sys.executable)
else:
    APP_BASE = os.path.dirname(__file__)
SAVE_DIR = os.path.join(APP_BASE, "reports")
os.makedirs(SAVE_DIR, exist_ok=True)

# -------------------------
# Load pipeline (robust)
# -------------------------
try:
    model = joblib.load(MODEL_PATH)
except FileNotFoundError:
    message = (
        f"Model file not found at:\n{MODEL_PATH}\n\n"
        "Make sure Gradient_Boosting_Final.pkl is placed next to gui.py or bundled with PyInstaller using --add-data."
    )
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Model not found", message)
        root.destroy()
    except Exception:
        print(message)
    raise
except Exception as e:
    if "No module named 'sklearn'" in str(e) or "sklearn" in str(e):
        message = (
            "The model requires scikit-learn to be available at runtime.\n\n"
            "Install scikit-learn in the environment used to build the executable, "
            "or rebuild the executable after installing scikit-learn."
        )
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("Missing dependency", message + f"\n\nDetails:\n{e}")
            root.destroy()
        except Exception:
            print(message)
        raise ImportError(message) from e
    else:
        raise

# -------------------------
# Get original feature names (exact strings saved during training)
# -------------------------
if hasattr(model, "feature_names"):
    feature_names = list(model.feature_names)
else:
    n = getattr(model, "n_features_in_", None)
    if n:
        feature_names = [f"feature_{i+1}" for i in range(n)]
    else:
        feature_names = []
        try:
            preproc = getattr(model, "named_steps", {}).get("preprocessor", None)
            if preproc is not None and hasattr(preproc, "transformers_"):
                cols = []
                for name, trans, cols_part in preproc.transformers_:
                    if isinstance(cols_part, (list, tuple)):
                        cols.extend(cols_part)
                if cols:
                    feature_names = list(cols)
        except Exception:
            pass
        if not feature_names:
            raise RuntimeError("Model does not contain feature_names. Re-train or attach feature_names to pipeline.")

# Remove any feature that contains "Sum of Span Length"
feature_names = [f for f in feature_names if "Sum of Span Length" not in f]

# -------------------------
# Salinity mapping by Location
# -------------------------
location_to_salinity = {
    "Bagerhat": "Very High","Barguna": "Very High","Barishal": "Very High","Bhola": "Very High",
    "Khulna": "Very High","Patuakhali": "Very High","Satkhira": "Very High",
    "Chandpur": "High","Chattogram": "High","Cox's Bazar": "High","Feni": "High",
    "Jhalokati": "High","Jessore": "High","Lakshmipur": "High","Narail": "High",
    "Noakhali": "High","Pirojpur": "High",
    "Brahmanbaria": "Medium","Cumilla": "Medium","Faridpur": "Medium","Gopalganj": "Medium",
    "Madaripur": "Medium","Munshiganj": "Medium","Narayanganj": "Medium","Shariatpur": "Medium",
    "Dhaka": "Low","Gazipur": "Low","Habiganj": "Low","Kishoreganj": "Low",
    "Moulvibazar": "Low","Narsingdi": "Low","Rajbari": "Low","Sunamganj": "Low",
    "Sylhet": "Low","Tangail": "Low",
    "Bandarban": "Very Low","Bogura": "Very Low","Chuadanga": "Very Low","Dinajpur": "Very Low",
    "Gaibanda": "Very Low","Jamalpur": "Very Low","Jhenaidah": "Very Low","Joypurhat": "Very Low",
    "Khagrachari": "Very Low","Kurigram": "Very Low","Kushtia": "Very Low","Lalmonirhat": "Very Low",
    "Magura": "Very Low","Manikganj": "Very Low","Meherpur": "Very Low","Naogaon": "Very Low",
    "Natore": "Very Low","Nawabganj": "Very Low","Netrokona": "Very Low","Nilphamari": "Very Low",
    "Pabna": "Very Low","Panchagarh": "Very Low","Rajshahi": "Very Low","Rangamati": "Very Low",
    "Rangpur": "Very Low","Sherpur": "Very Low","Sirajganj": "Very Low","Thakurgaon": "Very Low"
}

# -------------------------
# BNBC Z mapping by Town
# -------------------------
location_to_eq = {
    "Bagerhat": 0.12, "Bandarban": 0.28, "Barguna": 0.12, "Barishal": 0.12, "Bhola": 0.12,
    "Brahmanbaria": 0.28, "Chandpur": 0.20, "Chattogram": 0.28, "Chuadanga": 0.12, "Cumilla": 0.20,
    "Cox's Bazar": 0.28, "Dhaka": 0.20, "Dinajpur": 0.20, "Faridpur": 0.20, "Feni": 0.20,
    "Gaibanda": 0.28, "Gazipur": 0.20, "Gopalganj": 0.12, "Habiganj": 0.36, "Jamalpur": 0.36,
    "Jessore": 0.12, "Jhalokati": 0.12, "Jhenaidah": 0.12, "Joypurhat": 0.20, "Khagrachari": 0.28,
    "Khulna": 0.12, "Kishoreganj": 0.36, "Kurigram": 0.36, "Kushtia": 0.36, "Lakshmipur": 0.20,
    "Lalmonirhat": 0.28, "Madaripur": 0.20, "Magura": 0.12, "Manikganj": 0.20, "Meherpur": 0.12,
    "Moulvibazar": 0.36, "Munshiganj": 0.20, "Naogaon": 0.36, "Narail": 0.12, "Narayanganj": 0.20,
    "Narsingdi": 0.28, "Natore": 0.20, "Netrokona": 0.36, "Nilphamari": 0.36, "Noakhali": 0.20,
    "Pabna": 0.20, "Panchagarh": 0.20, "Patuakhali": 0.12, "Pirojpur": 0.12, "Rajbari": 0.20,
    "Rajshahi": 0.12, "Rangamati": 0.28, "Rangpur": 0.28, "Satkhira": 0.12, "Shariatpur": 0.20,
    "Sherpur": 0.36, "Sirajganj": 0.28, "Sunamganj": 0.36, "Sylhet": 0.36, "Tangail": 0.28,
    "Thakurgaon": 0.20, "Bogura": 0.28, "Nawabganj": 0.12
}
location_choices = sorted(set(list(location_to_salinity.keys()) + list(location_to_eq.keys())))

# -------------------------
# Extract categorical choices (best-effort)
# -------------------------
categorical_choices = {}
try:
    preproc = model.named_steps.get("preprocessor", None)
    if preproc is not None:
        cat_transformer = None
        if "cat" in preproc.named_transformers_:
            cat_transformer = preproc.named_transformers_["cat"]
        else:
            for name, tr in preproc.named_transformers_.items():
                if tr is not None and hasattr(tr, "named_steps") and "onehot" in tr.named_steps:
                    cat_transformer = tr
                    break
        if cat_transformer is not None:
            ohe = cat_transformer.named_steps.get("onehot", None)
            if ohe is not None and hasattr(ohe, "categories_"):
                cat_cols = getattr(model, "categorical_features", None)
                if cat_cols is None:
                    for name, trans, cols in preproc.transformers_:
                        if name == "cat":
                            cat_cols = list(cols)
                            break
                if cat_cols:
                    for col_name, cats in zip(cat_cols, ohe.categories_):
                        categorical_choices[col_name] = list(map(lambda x: str(x), cats))
except Exception:
    pass

# -------------------------
# Hard-coded dropdowns and mappings
# -------------------------
crossing_map = {
    "Railway": 30, "National Road": 25, "Regional Road": 20, "Zilla Road": 15,
    "Under Pass": 10, "Chanel": 5, "Cross Drainage": 5, "Swamp Land": 5,
    "River": 1, "Others": 0, "Unknown": 0
}
crossing_choices = list(crossing_map.keys())

roadclass_map = {"National Road": 30, "Regional Road": 20, "Zilla Road": 5, "Others": 0}
roadclass_choices = list(roadclass_map.keys())

traffic_map = {
    "Over 20000": 25, "15000 to 20000": 20, "10000 to 15000": 15,
    "5000 to 10000": 10, "1000 to 5000": 5, "Under 1000": 0
}
traffic_choices = list(traffic_map.keys())

# -------------------------
# Prediction label mapping
# -------------------------
classes = getattr(model, "classes_", None)
if classes is not None:
    label_map = {}
    letters = ["A", "B", "C"]
    for i, cls in enumerate(classes):
        try:
            key = int(cls)
        except Exception:
            key = cls
        label_map[key] = letters[i] if i < len(letters) else str(cls)
else:
    label_map = {0: "A", 1: "B", 2: "C"}

# -------------------------
# PDF report generator
# -------------------------
styles = getSampleStyleSheet()

def generate_pdf_report(input_dict, pred_label, probs=None, save_path=None):
    if save_path is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        save_path = os.path.join(SAVE_DIR, f"Bridge_Report_{ts}.pdf")

    c = pdf_canvas.Canvas(save_path, pagesize=A4)
    width, height = A4

    c.setFillColor(colors.HexColor("#2563EB"))
    c.setFont("Helvetica-Bold", 18)
    c.drawString(25*mm, height - 25*mm, "Bridge Damage Prediction Report")

    c.setFont("Helvetica", 9)
    c.setFillColor(colors.black)
    c.drawString(25*mm, height - 32*mm, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    c.drawString(25*mm, height - 36*mm, f"Model: Gradient Boosting Classifier")

    c.setStrokeColor(colors.grey)
    c.setLineWidth(0.5)
    c.line(25*mm, height - 38*mm, width - 25*mm, height - 38*mm)

    table_data = [["Feature", "Value"]]
    for k, v in input_dict.items():
        display_v = "" if (v is None or (isinstance(v, float) and np.isnan(v))) else str(v)
        table_data.append([k, display_v])

    table = Table(table_data, colWidths=[95*mm, 70*mm])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#e6f0ff")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.black),
        ("ALIGN", (0,0), (-1,-1), "LEFT"),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 9),
        ("BOTTOMPADDING", (0,0), (-1,0), 6),
        ("GRID", (0,0), (-1,-1), 0.25, colors.lightgrey)
    ]))

    tw, th = table.wrapOn(c, width - 50*mm, height)
    table.drawOn(c, 25*mm, height - 48*mm - th)

    y_after_table = height - 48*mm - th - 18*mm
    box_x = 25*mm
    box_y = y_after_table - 40*mm
    box_w = width - 50*mm
    box_h = 36*mm

    c.setFillColor(colors.HexColor("#f7fbff"))
    c.roundRect(box_x, box_y, box_w, box_h, 6, stroke=0, fill=1)

    c.setFont("Helvetica-Bold", 12)
    c.setFillColor(colors.HexColor("#2563EB"))
    c.drawString(box_x + 6*mm, box_y + box_h - 8*mm, "Damage Class Prediction")

    c.setFont("Helvetica-Bold", 28)
    color_map = {"A": colors.HexColor("#2e7d32"), "B": colors.HexColor("#f9a825"), "C": colors.HexColor("#c62828")}
    badge_color = color_map.get(pred_label, colors.HexColor("#2563EB"))
    c.setFillColor(badge_color)
    c.drawString(box_x + 6*mm, box_y + box_h - 22*mm, f"{pred_label}")

    c.setFont("Helvetica", 10)
    c.setFillColor(colors.black)
    if probs is not None and len(probs) >= 3:
        prob_text = f"Probabilities — A: {probs[0]:.3f}    B: {probs[1]:.3f}    C: {probs[2]:.3f}"
    elif probs is not None:
        prob_text = "Probabilities — " + "  ".join([f"{i}: {p:.3f}" for i, p in enumerate(probs)])
    else:
        prob_text = "Probabilities — Not available"
    c.drawString(box_x + 6*mm, box_y + 8*mm, prob_text)

    footer_y = 18*mm
    c.setFont("Helvetica-Oblique", 8)
    c.setFillColor(colors.grey)
    c.drawString(25*mm, footer_y, "This report was generated by the Bridge Damage Prediction System.")
    c.drawString(25*mm, footer_y - 6, "Disclaimer: The prediction is model-based and should be used as decision support only.")

    c.save()
    return save_path

# -------------------------
# Prediction function
# -------------------------
def predict_damage(generate_report=True):
    try:
        selected_location = location_widget.get().strip()
        if selected_location == "":
            derived_salinity = np.nan
            derived_eq = np.nan
        else:
            derived_salinity = location_to_salinity.get(selected_location, np.nan)
            derived_eq = location_to_eq.get(selected_location, np.nan)

        display_row = {}
        model_row = {}

        display_row["Location"] = selected_location if selected_location != "" else np.nan
        model_row["Location"] = selected_location if selected_location != "" else np.nan

        display_row["Salinity Level"] = derived_salinity
        model_row["Salinity Level"] = derived_salinity
        display_row["EQ Intensity"] = derived_eq
        model_row["EQ Intensity"] = derived_eq

        for fname in feature_names:
            if "Sum of Span Length" in fname:
                continue
            if fname in ("Salinity Level", "EQ Intensity"):
                continue

            widget_type, widget = inputs.get(fname, (None, None))
            if widget_type is None:
                display_row[fname] = np.nan
                model_row[fname] = np.nan
                continue

            if widget_type == "entry":
                raw = widget.get().strip()
                if raw == "":
                    display_row[fname] = np.nan
                    model_row[fname] = np.nan
                else:
                    display_row[fname] = raw
                    try:
                        if "." in raw:
                            model_row[fname] = float(raw)
                        else:
                            model_row[fname] = int(raw)
                    except Exception:
                        model_row[fname] = raw

            elif widget_type == "combobox":
                sel = widget.get().strip()
                if sel == "":
                    display_row[fname] = np.nan
                    model_row[fname] = np.nan
                else:
                    display_row[fname] = sel
                    if fname == "Crossing Under Bridge":
                        model_row[fname] = crossing_map.get(sel, 0)
                    elif fname == "Road Class":
                        model_row[fname] = roadclass_map.get(sel, 0)
                    elif fname == "Mean Traffic (AADT in thousand)":
                        model_row[fname] = traffic_map.get(sel, 0)
                    else:
                        model_row[fname] = sel
            else:
                display_row[fname] = np.nan
                model_row[fname] = np.nan

        input_cols = [c for c in feature_names if "Sum of Span Length" not in c]
        for extra in ["Location", "Salinity Level", "EQ Intensity"]:
            if extra not in input_cols:
                input_cols.append(extra)

        input_df = pd.DataFrame([model_row], columns=input_cols)

        pred_raw = model.predict(input_df)[0]
        try:
            pred_key = int(pred_raw)
        except Exception:
            pred_key = pred_raw
        pred_label = label_map.get(pred_key, str(pred_raw))

        probs = None
        try:
            proba = model.predict_proba(input_df)[0]
            if hasattr(model, "classes_"):
                classes = list(model.classes_)
                probs_aligned = [0.0, 0.0, 0.0]
                for cls, p in zip(classes, proba):
                    try:
                        idx = int(cls)
                    except Exception:
                        continue
                    if idx in (0, 1, 2):
                        probs_aligned[idx] = float(p)
                probs = probs_aligned
            else:
                probs = list(proba)
        except Exception:
            probs = None

        update_derived_fields()

        result_label.config(text=f"Predicted Damage Class: {pred_label}")
        if probs is not None:
            prob_label.config(text=f"A: {probs[0]*100:.2f}%   B: {probs[1]*100:.2f}%   C: {probs[2]*100:.2f}%")
        else:
            prob_label.config(text="Probabilities: Not available")

        if generate_report:
            save_path = generate_pdf_report(display_row, pred_label, probs=probs)
            try:
                if os.name == "nt":
                    os.startfile(save_path)
                else:
                    webbrowser.open(f"file://{os.path.abspath(save_path)}")
            except Exception:
                webbrowser.open(f"file://{os.path.abspath(save_path)}")

            messagebox.showinfo("Report Generated", f"Report saved to:\n{save_path}")

    except Exception as e:
        import traceback as _tb
        tb = _tb.format_exc()
        messagebox.showerror("Prediction Error", f"Failed to predict:\n{str(e)}\n\nTraceback:\n{tb}")

def clear_inputs():
    if location_choices:
        location_widget.current(0)
    update_derived_fields()
    for wtype, w in inputs.values():
        if wtype == "entry":
            try:
                w.delete(0, tk.END)
            except Exception:
                pass
        elif wtype == "combobox":
            try:
                if w['values']:
                    w.current(0)
                else:
                    w.set("")
            except Exception:
                pass

# -------------------------
# Build GUI (compact, tightened spacing, left area scrollable)
# -------------------------
root = tk.Tk()
root.title("Bridge Damage Prediction System")
root.geometry("1280x820")
root.configure(bg="#F3F6FB")

style = ttk.Style(root)
try:
    style.theme_use("clam")
except Exception:
    pass

style.configure("Header.TLabel", font=("Segoe UI", 20, "bold"), foreground="#0B5FFF", background="#F3F6FB")
style.configure("Sub.TLabel", font=("Segoe UI", 10), background="#F3F6FB")
style.configure("TButton", font=("Segoe UI", 10))
style.configure("TEntry", font=("Segoe UI", 10))
style.configure("TCombobox", font=("Segoe UI", 10))

# Header
header_frame = tk.Frame(root, bg="#F3F6FB")
header_frame.pack(fill="x", padx=14, pady=(10,6))

tk.Label(header_frame, text="Bridge Damage Prediction System", bg="#F3F6FB", fg="#0B5FFF", font=("Segoe UI", 20, "bold")).pack(anchor="w")
tk.Label(header_frame, text="Machine Learning Based Bridge Damage Classification", bg="#F3F6FB", fg="#374151", font=("Segoe UI", 10)).pack(anchor="w", pady=(2,0))
tk.Label(header_frame, text="Smart Prediction • Data Driven • Safer Infrastructure", bg="#F3F6FB", fg="#6B7280", font=("Segoe UI", 9, "italic")).pack(anchor="w", pady=(2,6))

# Content split: left scrollable area + right fixed panel
content_frame = tk.Frame(root, bg="#F3F6FB")
content_frame.pack(fill="both", expand=True, padx=14, pady=(0,10))

# Right frame (fixed)
right_frame = tk.Frame(content_frame, bg="#FFFFFF", bd=0, relief="flat", width=340)
right_frame.pack(side="right", fill="y", padx=(10,0), pady=0)
right_frame.pack_propagate(False)

# Left area: create a canvas with vertical scrollbar that will contain the input content frame
left_container = tk.Frame(content_frame, bg="#F3F6FB")
left_container.pack(side="left", fill="both", expand=True, padx=(0,10), pady=0)

left_canvas = tk.Canvas(left_container, bg="#FDFDFD", highlightthickness=0)
left_vscroll = ttk.Scrollbar(left_container, orient="vertical", command=left_canvas.yview)
left_canvas.configure(yscrollcommand=left_vscroll.set)

left_vscroll.pack(side="right", fill="y")
left_canvas.pack(side="left", fill="both", expand=True)

# This frame will hold all left-side content (sections)
left_frame = tk.Frame(left_canvas, bg="#FFFFFF")
# Create window inside canvas
left_canvas_window = left_canvas.create_window((0, 0), window=left_frame, anchor="nw")

# Update scrollregion when left_frame changes size
def _on_left_frame_configure(event):
    left_canvas.configure(scrollregion=left_canvas.bbox("all"))
left_frame.bind("<Configure>", _on_left_frame_configure)

# Make canvas resize the inner window width when the canvas size changes
def _on_canvas_configure(event):
    canvas_width = event.width
    # set the inner frame width to canvas width minus a small padding
    left_canvas.itemconfig(left_canvas_window, width=canvas_width - 4)
left_canvas.bind("<Configure>", _on_canvas_configure)

# Mouse wheel support (cross-platform)
def _on_mousewheel(event):
    # Windows and macOS
    if event.delta:
        # On Windows, event.delta is multiple of 120
        left_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
    else:
        # Linux: event.num == 4 (up) or 5 (down)
        if event.num == 4:
            left_canvas.yview_scroll(-3, "units")
        elif event.num == 5:
            left_canvas.yview_scroll(3, "units")

# Bind mouse wheel to canvas when cursor is over it
left_canvas.bind_all("<MouseWheel>", _on_mousewheel)      # Windows / macOS
left_canvas.bind_all("<Button-4>", _on_mousewheel)        # Linux scroll up
left_canvas.bind_all("<Button-5>", _on_mousewheel)        # Linux scroll down

# Helper to create sections with reduced spacing
def make_section(parent, title, subtitle=None):
    sec = tk.Frame(parent, bg="#FFFFFF", bd=0, relief="ridge")
    sec.pack(fill="x", padx=10, pady=(8,4))   # tightened spacing
    header = tk.Frame(sec, bg="#FFFFFF")
    header.pack(fill="x", padx=6, pady=(6,2))
    tk.Label(header, text=title, bg="#FFFFFF", fg="#0B5FFF", font=("Segoe UI", 11, "bold")).pack(side="left")
    if subtitle:
        tk.Label(header, text=subtitle, bg="#FFFFFF", fg="#6B7280", font=("Segoe UI", 9)).pack(side="right")
    body = tk.Frame(sec, bg="#FFFFFF")
    body.pack(fill="x", padx=6, pady=(0,6))
    return sec, body

# Location Information
loc_card, loc_body = make_section(left_frame, "Location Information", "Auto-derived")
loc_row = tk.Frame(loc_body, bg="#FFFFFF")
loc_row.pack(fill="x", pady=4)
tk.Label(loc_row, text="Location:", bg="#FFFFFF", font=("Segoe UI", 10)).pack(side="left", padx=(4,8))
loc_cb = ttk.Combobox(loc_row, values=location_choices, state="readonly", width=28)
if location_choices:
    loc_cb.current(0)
loc_cb.pack(side="left", padx=(0,8))
location_widget = loc_cb

tk.Label(loc_row, text="Salinity (Auto):", bg="#FFFFFF", font=("Segoe UI", 10)).pack(side="left", padx=(10,6))
sal_display = tk.Label(loc_row, text="", bg="#FEF3C7", relief="sunken", width=12, anchor="w", font=("Segoe UI", 9))
sal_display.pack(side="left", padx=(0,8))
tk.Label(loc_row, text="EQ Intensity (Auto):", bg="#FFFFFF", font=("Segoe UI", 10)).pack(side="left", padx=(10,6))
eq_display = tk.Label(loc_row, text="", bg="#E6F4EA", relief="sunken", width=6, anchor="w", font=("Segoe UI", 9))
eq_display.pack(side="left", padx=(0,8))

# Bridge Information (no Bridge Length here)
bridge_card, bridge_body = make_section(left_frame, "Bridge Information", f"Total Features in Model: {len(feature_names)}")
bgrid = tk.Frame(bridge_body, bg="#FFFFFF")
bgrid.pack(fill="x", pady=4)
bgrid.columnconfigure(0, weight=1)
bgrid.columnconfigure(1, weight=1)

bt_frame = tk.Frame(bgrid, bg="#FFFFFF")
bt_frame.grid(row=0, column=0, sticky="ew", padx=(4,6), pady=4)
tk.Label(bt_frame, text="Bridge Type", bg="#FFFFFF", font=("Segoe UI", 9)).pack(anchor="w")
bt_cb = ttk.Combobox(bt_frame, values=categorical_choices.get("Bridge Type", []), state="readonly")
if bt_cb['values']:
    bt_cb.current(0)
bt_cb.pack(fill="x", pady=(6,0))

cu_frame = tk.Frame(bgrid, bg="#FFFFFF")
cu_frame.grid(row=0, column=1, sticky="ew", padx=(6,4), pady=4)
tk.Label(cu_frame, text="Crossing Under Bridge", bg="#FFFFFF", font=("Segoe UI", 9)).pack(anchor="w")
cu_cb = ttk.Combobox(cu_frame, values=crossing_choices, state="readonly")
if cu_cb['values']:
    cu_cb.current(0)
cu_cb.pack(fill="x", pady=(6,0))

rc_frame = tk.Frame(bgrid, bg="#FFFFFF")
rc_frame.grid(row=1, column=0, sticky="ew", padx=(4,6), pady=4)
tk.Label(rc_frame, text="Road Class", bg="#FFFFFF", font=("Segoe UI", 9)).pack(anchor="w")
rc_cb = ttk.Combobox(rc_frame, values=roadclass_choices, state="readonly")
if rc_cb['values']:
    rc_cb.current(0)
rc_cb.pack(fill="x", pady=(6,0))

# Traffic Information
traffic_card, traffic_body = make_section(left_frame, "Traffic Information")
tframe = tk.Frame(traffic_body, bg="#FFFFFF")
tframe.pack(fill="x", pady=4)
tk.Label(tframe, text="Mean Traffic (PCU/Day)", bg="#FFFFFF", font=("Segoe UI", 9)).pack(anchor="w")
mt_entry = ttk.Combobox(tframe, values=traffic_choices, state="readonly")
if mt_entry['values']:
    mt_entry.current(0)
mt_entry.pack(fill="x", pady=(6,0))

# Additional Parameters (Bridge Length only here)
compact_card, compact_body = make_section(left_frame, "Additional Parameters", "Provide remaining feature values")
compact_frame = tk.Frame(compact_body, bg="#FFFFFF")
compact_frame.pack(fill="both", expand=True, pady=(4,6))

left_compact = tk.Frame(compact_frame, bg="#FFFFFF")
right_compact = tk.Frame(compact_frame, bg="#FFFFFF")
left_compact.grid(row=0, column=0, sticky="nsew", padx=(4,6))
right_compact.grid(row=0, column=1, sticky="nsew", padx=(6,4))
compact_frame.columnconfigure(0, weight=1)
compact_frame.columnconfigure(1, weight=1)

inputs = {}

def add_compact_entry(parent, label_text, key):
    w = tk.Frame(parent, bg="#FFFFFF")
    w.pack(fill="x", pady=6)
    tk.Label(w, text=label_text, bg="#FFFFFF", font=("Segoe UI", 9)).pack(anchor="w")
    ent = ttk.Entry(w)
    ent.pack(fill="x", pady=(6,0))
    inputs[key] = ("entry", ent)
    return ent

def add_compact_combobox(parent, label_text, key, choices):
    w = tk.Frame(parent, bg="#FFFFFF")
    w.pack(fill="x", pady=6)
    tk.Label(w, text=label_text, bg="#FFFFFF", font=("Segoe UI", 9)).pack(anchor="w")
    cb = ttk.Combobox(w, values=choices, state="readonly")
    if cb['values']:
        cb.current(0)
    cb.pack(fill="x", pady=(6,0))
    inputs[key] = ("combobox", cb)
    return cb

# Place Bridge Length only once in Additional Parameters (left column)
bl_entry = add_compact_entry(left_compact, "Bridge Length (m)", "Bridge Length")

# Fill remaining features alternating columns, skipping those already placed and skipping any Bridge Length duplicates
col = 0
for fname in feature_names:
    if fname in ("Location", "Salinity Level", "EQ Intensity"):
        continue
    if "Sum of Span Length" in fname:
        continue
    # Skip fields already explicitly placed
    if fname in ("Bridge Type", "Crossing Under Bridge", "Road Class", "Mean Traffic (AADT in thousand)", "Bridge Length", "Bridge Length (m)", "Total Bridge Length"):
        continue

    target = left_compact if col == 0 else right_compact
    col = 1 - col

    label_text = "Mean Traffic (AADT)" if fname == "Mean Traffic (AADT in thousand)" else fname

    if fname == "Bridge Type":
        add_compact_combobox(target, label_text, fname, categorical_choices.get(fname, []))
    elif fname == "Crossing Under Bridge":
        add_compact_combobox(target, label_text, fname, crossing_choices)
    elif fname == "Road Class":
        add_compact_combobox(target, label_text, fname, roadclass_choices)
    elif fname == "Mean Traffic (AADT in thousand)":
        add_compact_combobox(target, label_text, fname, traffic_choices)
    else:
        add_compact_entry(target, label_text, fname)

# Wire explicitly created widgets into inputs dict
inputs["Bridge Type"] = ("combobox", bt_cb)
inputs["Crossing Under Bridge"] = ("combobox", cu_cb)
inputs["Road Class"] = ("combobox", rc_cb)
inputs["Mean Traffic (AADT in thousand)"] = ("combobox", mt_entry)
# Map Bridge Length to the model feature name(s) used by the pipeline (single mapping)
if "Bridge Length" in feature_names:
    inputs["Bridge Length"] = ("entry", bl_entry)
elif "Bridge Length (m)" in feature_names:
    inputs["Bridge Length (m)"] = ("entry", bl_entry)
elif "Total Bridge Length" in feature_names:
    inputs["Total Bridge Length"] = ("entry", bl_entry)
else:
    inputs["Bridge Length"] = ("entry", bl_entry)

# Derived fields update
def update_derived_fields(event=None):
    loc = location_widget.get().strip()
    if loc == "":
        sal = ""
        z = ""
    else:
        sal = location_to_salinity.get(loc, "")
        z_val = location_to_eq.get(loc, None)
        z = f"{z_val:.2f}" if z_val is not None else ""
    sal_display.config(text=sal if sal is not None else "")
    eq_display.config(text=z if z is not None else "")

location_widget.bind("<<ComboboxSelected>>", update_derived_fields)
update_derived_fields()

# Right frame: Prediction Result and controls
result_card = tk.Frame(right_frame, bg="#F8FAFF", bd=0, relief="ridge")
result_card.pack(fill="both", expand=False, padx=10, pady=(10,6))

tk.Label(result_card, text="Prediction Result", bg="#F8FAFF", fg="#0B5FFF", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=10, pady=(8,4))

result_label = tk.Label(result_card, text="Predicted Damage Class: —", bg="#F8FAFF", fg="#111827", font=("Segoe UI", 12, "bold"))
result_label.pack(anchor="w", padx=10, pady=(4,2))

prob_label = tk.Label(result_card, text="A: —   B: —   C: —", bg="#F8FAFF", fg="#374151", font=("Segoe UI", 10))
prob_label.pack(anchor="w", padx=10, pady=(0,8))

controls_card = tk.Frame(right_frame, bg="#FFFFFF", bd=0, relief="flat")
controls_card.pack(fill="x", padx=10, pady=(6,10))

predict_btn = ttk.Button(controls_card, text="Predict & Generate PDF Report", width=28, command=lambda: threading.Thread(target=predict_damage, args=(True,), daemon=True).start())
predict_btn.pack(fill="x", pady=(6,6))

preview_btn = ttk.Button(controls_card, text="Predict (No PDF)", width=28, command=lambda: threading.Thread(target=predict_damage, args=(False,), daemon=True).start())
preview_btn.pack(fill="x", pady=(0,6))

clear_btn = ttk.Button(controls_card, text="Clear All Inputs", width=28, command=clear_inputs)
clear_btn.pack(fill="x", pady=(0,6))

view_reports_btn = ttk.Button(controls_card, text="View Reports Folder", width=28, command=lambda: webbrowser.open(f"file://{os.path.abspath(SAVE_DIR)}"))
view_reports_btn.pack(fill="x", pady=(0,6))

# Footer info (Author names displayed as requested, multi-line)
info_card = tk.Frame(right_frame, bg="#FFFFFF", bd=0, relief="flat")
info_card.pack(fill="x", padx=10, pady=(0,10))
tk.Label(info_card, text="Thesis Project: Bridge Damage Classification", bg="#FFFFFF", fg="#374151", font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(6,2))
tk.Label(info_card, text="Author:\nM Nafis Farhan Rubai\nRIAD SHAHARIAR\nMD. TAHMIDUL HAQ", bg="#FFFFFF", fg="#6B7280", font=("Segoe UI", 9), justify="left").pack(anchor="w", pady=(0,6))
tk.Label(info_card, text="Version 1.0", bg="#FFFFFF", fg="#6B7280", font=("Segoe UI", 8)).pack(anchor="w", pady=(0,6))

# Bottom footer
footer = tk.Frame(root, bg="#F3F6FB")
footer.pack(fill="x", padx=14, pady=(0,10))
tk.Label(footer, text="© Bridge Management System(BMS 2018) | Built with Tkinter & Machine Learning", bg="#F3F6FB", fg="#6B7280", font=("Segoe UI", 9)).pack(anchor="w")

# Ensure inputs dict contains all feature widgets (create hidden entries for any missing)
for fname in feature_names:
    if fname in ("Location", "Salinity Level", "EQ Intensity"):
        continue
    if fname not in inputs:
        hidden = ttk.Entry(root)
        inputs[fname] = ("entry", hidden)

# Ensure canvas scrollregion is correct at startup
left_canvas.update_idletasks()
left_canvas.configure(scrollregion=left_canvas.bbox("all"))

# Start GUI
if __name__ == "__main__":
    try:
        root.mainloop()
    except Exception:
        try:
            messagebox.showerror("Fatal Error", "An unexpected error occurred. See console for details.")
        except Exception:
            pass
        raise
